from tkinter import *
import face_recon as fr
root = Tk()
u_id = StringVar()
name = StringVar()


#train
Label(root,text="user_id").place(x=5,y=10)
Entry(root,bd=2,textvariable=u_id).place(x=5,y=30)

Label(root,text="name").place(x=5,y=50)
Entry(root,bd=2,textvariable=name).place(x=5,y=70)
def dataset():
    user_id = u_id.get()
    uname = name.get() 
    

    fr.data_set(user_id,uname)
    
def train():
 	user_id = u_id.get()
 	fr.train()


def detect():
	fr.detector()

Button(root,text="make data set",command=dataset).place(x=10,y=100)
Button(root,text="train",command=train).place(x=10,y=130)
Button(root,text="detect faces",command=detect).place(x=10,y=160)
root.mainloop()
